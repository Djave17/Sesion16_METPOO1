package model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;


/*Autor → Libro: @OneToMany (un autor tiene muchos libros)
Libro → Autor: @ManyToOne (cada libro tiene un autor)
Libro ↔ Categoria: @ManyToMany (libros pueden tener varias categorías y viceversa)
*/
@Entity
@Getter
@Setter
public class Libro {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    //Titulo
    @Column(nullable = false)
    private String titulo;

    @Column(nullable = false)
    private Integer anioPublicacion;

    

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "autor_id", nullable = false, foreignKey = @ForeignKey(name = "fk_libro_autor"))
    private Autor autor;


}
